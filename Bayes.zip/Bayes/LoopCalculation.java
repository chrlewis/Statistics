import java.math.BigDecimal;

/**
 * class LoopCalculation uses objects from PrizeDoor and CompetitorGuess 
 * to play a game of Let's Make A Deal. The door hiding the prize and the
 * initial guess from the game contestant are selected at random. A loop
 * is executed that runs through all possibilities of initial door
 * selection, location of prize, and Monty's opening of a door. In each 
 * case it is assumed the contestant believes in Bayes Theorem and changes
 * the initial door selection
 * @author chrlewischrlewis
 *
 */
public class LoopCalculation {
	
	int correctGuess;
	int counter;
	double percent;
	PrizeDoor myPrizeDoor;
	CompetitorGuess myCompetitorGuess;
	
		/**
	 * @return the correctGuess
	 */
	public int getCorrectGuess() {
		return correctGuess;
	}

	/**
	 * @param correctGuess the correctGuess to set
	 */
	public void setCorrectGuess(int correctGuess) {
		this.correctGuess = correctGuess;
	}

	/**
	 * @return the counter
	 */
	public int getCounter() {
		return counter;
	}

	/**
	 * @param counter the counter to set
	 */
	public void setCounter(int counter) {
		this.counter = counter;
	}

	/**
	 * @return the percent
	 */
	public double getPercent() {
		return percent;
	}

	/**
	 * @param percent the percent to set
	 */
	public void setPercent(double percent) {
		this.percent = percent;
	}
/**
 * run method
 * @param no parameters
 * @return no return value
 * instantiates objects to select random prize door and competitor guess
 * then evaluates all possibilities to determine whether Bayes Theorem
 *  gives a correct guess for the random conditions set. Iterates for 
 *  1,000,000 times
 */
	public void run() {
		setCorrectGuess(0);
		setCounter(0);
		BigDecimal bigDecimal;
		BigDecimal roundedPercent;

		while (counter < 1000000) {
			myPrizeDoor = new PrizeDoor();
			myCompetitorGuess = new CompetitorGuess();
			myPrizeDoor.pickPrizeDoor();
			myCompetitorGuess.competitorDoorPick();
			if (myPrizeDoor.isPrizeDoorA() && myCompetitorGuess.isCompetitorGuessA()){
				//do not increment correctGuess as changing door choice yields a loss
			}
			else if (myPrizeDoor.isPrizeDoorA() && myCompetitorGuess.isCompetitorGuessB()){
				correctGuess++;
				//correct guess as Monty opens door C, and I swap from B to A
			}
			else if (myPrizeDoor.isPrizeDoorA() && myCompetitorGuess.isCompetitorGuessC()){
				correctGuess++;
				//correct guess as Monty can only open door B and I swap from C to A
			}
			else if (myPrizeDoor.isPrizeDoorB() && myCompetitorGuess.isCompetitorGuessA()){
				correctGuess++;
				//correct guess as Monty has to open door C and I change from A to B
			}
			else if (myPrizeDoor.isPrizeDoorB() && myCompetitorGuess.isCompetitorGuessB()){
				//do not increment correctGuess as a change of door loses
			}
			else if (myPrizeDoor.isPrizeDoorB() && myCompetitorGuess.isCompetitorGuessC()){
				correctGuess++;
				//correct guess as Monty has to open door A and I swap from C to A
			}
			else if (myPrizeDoor.isPrizeDoorC() && myCompetitorGuess.isCompetitorGuessA()){
				correctGuess++;
				//correct guess as Monty has to open door B, and I swap from A to C
			}
			else if (myPrizeDoor.isPrizeDoorC() && myCompetitorGuess.isCompetitorGuessB()){
				correctGuess++;
				//correct guess as Monty has to open door A and I change from B to A
			}
			else {
				//do not increment correctGuess, as if the prize is behind door C and
				//initial pick is door C, changing doors loses
			}
			counter++;
			
		}//end while loop
		//calculate percent of correct guesses and round to two decimal places, 
		//then display outcome
		setPercent( 100 * ( (double) correctGuess / counter));
		bigDecimal = new BigDecimal(getPercent());
		roundedPercent = bigDecimal.setScale(2, BigDecimal.ROUND_HALF_UP);
		
		System.out.println("Correctly guessed " +getCorrectGuess() + " out of " 
		+ getCounter() + ". This is equal to " + roundedPercent +"%. A value"
				+ " greater than 50% indicates following the Bayes Theorem"
				+ "\nrecommendation to switch doors after Monty opens a door works.");
		
	}//end run method
	
}//end class

