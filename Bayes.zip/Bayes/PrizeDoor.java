/**
 * This class selects at random a 
 * door behind which, the prize is hidden
 */
import java.lang.Math;

public class PrizeDoor {
	
	double varCounter;
	boolean prizeDoorA;
	boolean prizeDoorB;
	boolean prizeDoorC;
	
	/**
	 * @return the varCounter
	 */
	public double getVarCounter() {
		return varCounter;
	}

	/**
	 * @param varCounter the varCounter to set
	 */
	public void setVarCounter(double varCounter) {
		this.varCounter = varCounter;
	}

	/**
	 * @return the prizeDoorA
	 */
	public boolean isPrizeDoorA() {
		return prizeDoorA;
	}

	/**
	 * @param prizeDoorA the prizeDoorA to set
	 */
	public void setPrizeDoorA(boolean prizeDoorA) {
		this.prizeDoorA = prizeDoorA;
	}

	/**
	 * @return the prizeDoorB
	 */
	public boolean isPrizeDoorB() {
		return prizeDoorB;
	}

	/**
	 * @param prizeDoorB the prizeDoorB to set
	 */
	public void setPrizeDoorB(boolean prizeDoorB) {
		this.prizeDoorB = prizeDoorB;
	}

	/**
	 * @return the prizeDoorC
	 */
	public boolean isPrizeDoorC() {
		return prizeDoorC;
	}

	/**
	 * @param prizeDoorC the prizeDoorC to set
	 */
	public void setPrizeDoorC(boolean prizeDoorC) {
		this.prizeDoorC = prizeDoorC;
	}
/**
 * Method pickPrizeDoor has no parameters and does not return anything.
 * A local variable is created to house a random value between 0 and 1.
 * Depending on the value of that random value, either door A, B or C
 * is set to have a true value, indicating that is where the prize is located
 */
	public void pickPrizeDoor() {
		
		varCounter = Math.random();
		
		if (varCounter < 0.33) {
			setPrizeDoorA(true);
		}
		else if (varCounter < 0.66) {
			setPrizeDoorB(true);
		}
		else {
			setPrizeDoorC(true);
		}//end else

	}//end method pickPrizeDoor
	
}//end class

