/**
 * Class BayesTestDrive runs the program
 * @author chrlewischrlewis
 *
 */
public class BayesTestDrive {
/**
 * @return, nothing is returned
 * @param args
 * The main method instantiates the loop that accumulates the outcome
 * of the specified number of games to determine if Bayes Theorem
 * gives a positive recommendation
 */
	public static void main (String[] args){
		LoopCalculation myLoopCalculation = new LoopCalculation();
		myLoopCalculation.run();
	}
}
