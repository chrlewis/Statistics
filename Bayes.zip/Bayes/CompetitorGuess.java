/**
 * Class CompetitorGuess randomly selects a door that represents the initial
 * guess of the contestant. The contestant will act in a Bayesian way, in that
 * once the game host (Monty) opens a door, the contestant will change their
 * initial selection of door.
 */
import java.lang.Math;

public class CompetitorGuess {
	
	double competitorVarCounter;
	boolean competitorGuessA;
	boolean competitorGuessB;
	boolean competitorGuessC;
	
		/**
	 * @return the competitorVarCounter
	 */
	public double getCompetitorVarCounter() {
		return competitorVarCounter;
	}

	/**
	 * @param competitorVarCounter the competitorVarCounter to set
	 */
	public void setCompetitorVarCounter(double competitorVarCounter) {
		this.competitorVarCounter = competitorVarCounter;
	}

	/**
	 * @return the competitorGuessA
	 */
	public boolean isCompetitorGuessA() {
		return competitorGuessA;
	}

	/**
	 * @param competitorGuessA the competitorGuessA to set
	 */
	public void setCompetitorGuessA(boolean competitorGuessA) {
		this.competitorGuessA = competitorGuessA;
	}

	/**
	 * @return the competitorGuessB
	 */
	public boolean isCompetitorGuessB() {
		return competitorGuessB;
	}

	/**
	 * @param competitorGuessB the competitorGuessB to set
	 */
	public void setCompetitorGuessB(boolean competitorGuessB) {
		this.competitorGuessB = competitorGuessB;
	}

	/**
	 * @return the competitorGuessC
	 */
	public boolean isCompetitorGuessC() {
		return competitorGuessC;
	}

	/**
	 * @param competitorGuessC the competitorGuessC to set
	 */
	public void setCompetitorGuessC(boolean competitorGuessC) {
		this.competitorGuessC = competitorGuessC;
	}
/**
 * method competitorDoorPick assigns a random value to a local
 * variable and uses that value to choose one of three doors,
 * either door A, B or C.
 */
	public void competitorDoorPick() {
		
		competitorVarCounter = Math.random();
		
		if (competitorVarCounter < 0.33) {
			setCompetitorGuessA(true);
		}
		else if (competitorVarCounter < 0.66) {
			setCompetitorGuessB(true);
		}
		else {
			setCompetitorGuessC(true);
		}
	}//end competitorDoorPick method
}//end class

